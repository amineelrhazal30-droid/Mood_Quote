# Technical Architecture — Mood Tracker

## Overview

Mood Tracker is a command-line application written in **C** that:

1. Reads the user's current mood from standard input
2. Sends a prompt to the **Google Gemini API** (via libcurl + REST/JSON)
3. Parses the AI response using **cJSON**
4. Persists the mood + quote locally in **SQLite**
5. Syncs the record to **Supabase** (cloud PostgreSQL via REST)

---

## Module Breakdown

### `main.c` — Entry point

Responsibilities:
- Validate required environment variables (`GEMINI_API_KEY`, etc.)
- Initialize and clean up libcurl globally
- Read mood from stdin (bounded `fgets` to prevent overflow)
- Call helpers in the correct order: `fetch_gemini_quote` → `sanitize_string` → `save_locally` → `sync_cloud`

Does **not** contain business logic — all logic lives in `core.c`.

---

### `core.c` / `core.h` — Business logic

All functions here are independently testable with no live network dependency.

#### `sanitize_string(char *s)`
Replaces `'` and `"` with backtick in-place.  
Prevents SQL injection into SQLite and JSON corruption in the Supabase payload.

#### `build_gemini_payload(char *buf, size_t size, const char *mood) → int`
Constructs the Gemini REST request body as a JSON string.  
Returns 0 on success, -1 if the buffer is too small or mood is NULL.

#### `parse_gemini_quote(const char *response) → char *`
Extracts the `"quote"` field from Gemini's nested JSON response using cJSON.  
The Gemini response wraps the AI-generated JSON inside `candidates[0].content.parts[0].text`.  
Returns a `malloc`'d string — the caller must `free()` it. Returns NULL on failure.

#### `save_locally(const char *db_path, const char *mood, const char *quote) → int`
Opens (or creates) a SQLite database at `db_path`.  
Creates the `moods` table if absent.  
Inserts one row using a prepared statement (safe against SQL injection).  
Returns 0 on success, a non-zero SQLite error code otherwise.

#### `sync_cloud(mood, quote, supabase_url, supabase_key) → int`
POSTs a JSON payload to Supabase via libcurl.  
If `supabase_url` or `supabase_key` are NULL, reads from environment variables.  
SSL verification is **enabled**.  
Returns 0 on success, the CURLcode on failure (non-fatal — logged to stderr).

---

### `test_main.c` — Unit tests

A self-contained test runner using a minimal custom assert macro framework.  
No external test library required.

Test groups:
- `test_sanitize()` — 6 cases including NULL and empty string safety
- `test_build_payload()` — verifies correct JSON shape, buffer overflow protection
- `test_parse_gemini()` — valid response, missing fields, invalid JSON, NULL
- `test_save_locally()` — full SQLite round-trip using a `/tmp/` test DB

Exit code: 0 if all pass, 1 if any fail (compatible with CI).

---

## Data Flow Diagram

```
stdin
  │  "happy"
  ▼
main.c
  │
  ├─► build_gemini_payload()
  │       │  JSON: {"contents":[...]}
  │       ▼
  │   libcurl POST ──────────────────────► Gemini API
  │                                             │
  │   ◄────────────── raw JSON response ────────┘
  │
  ├─► parse_gemini_quote()
  │       │  "Keep going, you can do it."
  │       ▼
  ├─► sanitize_string()
  │       │  (no-op if clean)
  │       ▼
  ├─► save_locally()
  │       │
  │       ▼
  │   SQLite (moods.db)
  │   ┌──────────────────────────────────┐
  │   │ id │ date     │ mood  │ quote    │
  │   ├────┼──────────┼───────┼──────────┤
  │   │  1 │ 2026-... │ happy │ Keep ... │
  │   └──────────────────────────────────┘
  │
  └─► sync_cloud()
          │  JSON POST
          ▼
      Supabase REST API (cloud)
```

---

## Database Schema

### Local (SQLite — `moods.db`)

```sql
CREATE TABLE IF NOT EXISTS moods (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    date  DATETIME DEFAULT CURRENT_TIMESTAMP,
    mood  TEXT NOT NULL,
    quote TEXT NOT NULL
);
```

### Cloud (Supabase — PostgreSQL)

Same schema, managed via the Supabase dashboard.  
Access is via the REST API using the `anon` key + Row Level Security (RLS).

---

## Security Notes

| Issue | Mitigation |
|-------|-----------|
| API keys in source code | Keys loaded from environment variables at runtime; `.env` is in `.gitignore` |
| SSL disabled | Removed `CURLOPT_SSL_VERIFYPEER = 0`; standard TLS verification active |
| SQL injection | Prepared statements with `sqlite3_bind_text()` |
| JSON injection in cloud sync | `sanitize_string()` removes `'` and `"` before payload construction |
| Buffer overflow on mood input | `fgets(mood, 64, stdin)` bounds input; empty string checked |

---

## Build System

The `Makefile` auto-detects the OS via `uname`:

- **Linux / macOS**: links `-lcurl`
- **Windows (MinGW)**: links `-lcurl -lws2_32 -lwldap32 -lcrypt32 -lnormaliz` and defines `CURL_STATICLIB`

Targets:
- `make` — build `mood_tracker`
- `make test` — build and run `mood_test`
- `make clean` — remove build artifacts

---

## CI/CD Pipeline (GitHub Actions)

File: `.github/workflows/ci.yml`

On every push to `main`/`master` and on pull requests:
1. `apt-get install libcurl4-openssl-dev`
2. `make all` — ensures the production binary compiles cleanly
3. `make test` — runs all unit tests; pipeline fails on any test failure

---

## Deployment

Platform: **Itch.io** (desktop binary distribution)

Steps:
1. Build on the target OS: `make`
2. Package: `zip mood_tracker_v1.zip mood_tracker README.md`
3. Upload to Itch.io project page and publish
4. Update the demo URL in `README.md`
